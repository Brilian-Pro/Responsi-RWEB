<?php

class Home extends CI_Controller{

    public function __construct(){
        parent::__construct();
        $this->load->model('M_data');
        $this->load->helper('url');
    }

    public function index(){
        $data['dt_pemilik'] = $this->M_data->tampil_data();
        $this->load->view('V_tampil', $data);
    }

    public function tambah(){
        $this->load->view('V_form');
    }

    function tambah_data(){
        $nama = $this->input->post('nama');
        $nik = $this->input->post('nik');
        $no_kendaraan = $this->input->post('no_kendaraan');
        $no_rangka = $this->input->post('no_rangka');

        $data = array(
            'nama'=> $nama,
            'nik'=>$nik,
            'no_kendaraan'=>$no_kendaraan,
            'no_rangka'=>$no_rangka,
        );
        $this->M_data->input_data($data, 'dt_pemilik');
        redirect('home/index');
    }
}

?>