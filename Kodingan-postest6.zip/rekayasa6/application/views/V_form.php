<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">
  <h2>Formulir Pendataan Kendaraan Bermotor</h2>
  <form action="<?php echo base_url(). 'home/tambah_data';?>" method="post">
    <div class="form-group">
      <label for="nama">Nama :</label>
      <input type="text" class="form-control" id="nama" placeholder="Masukkan Nama" name="nama">
    </div>
    <div class="form-group">
      <label for="nik">NIK :</label>
      <input type="text" class="form-control" id="nik" placeholder="Masukkan NIK" name="nik">
    </div>
    <div class="form-group">
      <label for="no.kendaraan">Nomor Kendaraan :</label>
      <input type="text" class="form-control" id="no.kendaraan" placeholder="Masukkan nomor Kendaraan" name="no.kendaraan">
    </div>
    <div class="form-group">
      <label for="mo.rangka">Nomor Rangka :</label>
      <input type="text" class="form-control" id="no.rangka" placeholder="Masukkan Nomor Rangka" name="no.rangka">
    </div>
    <button type="submit" class="btn btn-primary">Submit</button>
  </form>
</div>

</body>
</html>
