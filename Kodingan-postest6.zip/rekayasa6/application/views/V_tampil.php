<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
</head>
<body>
<div class="container">
  <h2>Data Pemilik Kendaraan Bermotor</h2>           
  <table class="table">
    <thead>
      <tr>
        <th>Nama</th>
        <th>NIK</th>
        <th>NO.Kendaraan</th>
        <th>No.Rangka</th>
      </tr>
    </thea>
    <tbody>
        <?php foreach($dt_pemilik as $data):?>
      <tr>
        <td><?php echo $data->nama?></td>
        <td><?php echo $data->nik?></td>
        <td><?php echo $data->no_Kendaraan?></td>
        <td><?php echo $data->no_rangka?></td>
      </tr>
      <?php endforeach ?>
    </tbody>
        <tr>
            <td>
            <a href="<?php echo base_url(). 'home/tambah';?>" class="btn btn-primary">Tambah data</a>
        </tr>
  </table>
</div>
</body>
</html>