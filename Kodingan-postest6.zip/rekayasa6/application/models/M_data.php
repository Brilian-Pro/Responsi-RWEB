<?php

class M_data extends CI_Model{
    function tampil_data(){
        $query = $this->db->query("SELECT*FROM dt_pemilik");
        return $query->result();
    }

    function input_data($data){
        $this->db->insert('dt_pemilik',$data);
    }
}
?>